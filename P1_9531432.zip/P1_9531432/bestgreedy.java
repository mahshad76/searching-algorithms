import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;


public class bestgreedy {
    ArrayList<Integer> neighbers = new ArrayList<>();
    ArrayList<Integer> res = new ArrayList<>();
public static int cost=0,memory=1,explore=0;
    public void best(int source, int goal, int[][] adjacency_matrix, int[] distance, int number_of_nodes) {
        boolean[] visited = new boolean[number_of_nodes + 1];
        int k = 1;

        int element = source;
        visited[element] = true;
        res.add(element);
        System.out.println(element);
        explore++;
        while (k <= number_of_nodes) {

            if (adjacency_matrix[element][k] != 0 && visited[k] == false) {

                neighbers.add(k);
                memory++;

            }
            k++;
        }

        int minimum = min(neighbers, distance);

        int my = neighbers.get(minimum);

        neighbers.remove(minimum);
        memory--;
        if (my == goal) {
            cost=cost+adjacency_matrix[element][my];
            System.out.println(goal);
        } else {
            cost=cost+adjacency_matrix[element][my];
            best(my, goal, adjacency_matrix, distance, number_of_nodes);
        }


    }

    public static void main(String[] args) {
        int number_of_nodes, source;
        Scanner scanner = null;
        try {
            System.out.println("Enter the number of nodes in the graph");
            scanner = new Scanner(System.in);
            number_of_nodes = scanner.nextInt();
            boolean visited[] = new boolean[number_of_nodes + 1];
            int adjacency_matrix[][] = new int[number_of_nodes + 1][number_of_nodes + 1];
            int[] distance = new int[number_of_nodes + 1];
            System.out.println("Enter the adjacency matrix");
            for (int i = 1; i <= number_of_nodes; i++)
                for (int j = 1; j <= number_of_nodes; j++)
                    adjacency_matrix[i][j] = scanner.nextInt();

            System.out.println("Enter the source for the graph");
            source = scanner.nextInt();
            System.out.println("Enter the goal");
            int goal = scanner.nextInt();
            int i = 1;
            int j = 1;

         distance[1]=380;
            distance[2]=374;
            distance[3]=366;
            distance[4]=329;
            distance[5]=244;
            distance[6]=241;
            distance[7]=242;
            distance[8]=253;
            distance[9]=193;
            distance[10]=160;
            distance[11]=178;
            distance[12]=98;
            distance[13]=0;
            distance[14]=77;
            distance[15]=80;
            distance[16]=199;
            distance[17]=226;
            distance[18]=234;
            distance[19]=151;
            distance[20]=161;


            bestgreedy greedy = new bestgreedy();
            greedy.best(source, goal, adjacency_matrix, distance, number_of_nodes);
            System.out.print('\n');
            System.out.println("cost" + cost);
            System.out.println("memory"+memory);
            System.out.println("explore"+explore);

        } catch (InputMismatchException inputMismatch) {
            System.out.println("Wrong Input format");
        }
        scanner.close();

    }

    public int min(ArrayList<Integer> neighbers, int[] distance) {
        int mini = 10000;
        int v = 0;

        for (int t = 0; t < neighbers.size(); t++) {
            if (distance[neighbers.get(t)] < mini) {

                mini = distance[neighbers.get(t)];
                v = t;
            }
        }
        return v;

    }
}
