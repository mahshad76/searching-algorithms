import java.awt.*;
import java.util.*;


public class jenetic {

    public static int popu = 0;
    public static int number_no_nodes = 0;
    public static  int dd=1;
    public static int edges=0;

    public static int i1 = 1;
    public static int j1 = 1;
    public static int c = 0;
    public static void jen(int[][] adjacency_matrix, int[] color) {
        int[][] result = new int[popu + 1][number_no_nodes + 1];
        int[] state = new int[number_no_nodes + 1];
        jenetic h = new jenetic();
        result = random(color);
        float shayestegi = 0;
        ArrayList<Float> shayeste = new ArrayList<>();


        int edges = 0;
        for (int t = 1; t <= number_no_nodes; t++) {
            for (int e = 1; e <= number_no_nodes; e++) {
                if (adjacency_matrix[t][e] != 0) {
                    edges++;
                }
            }
        }
        System.out.print('\n');
        for (int v1 = 1; v1 <= popu; v1++) {

            int s = 1;
            for (int v2 = 1; v2 <= number_no_nodes; v2++) {
                state[s] = result[v1][v2];

                System.out.print(state[s]);
                s++;

            }
            System.out.print('\n');
            shayestegi = F(state, edges);

            System.out.println(shayestegi);
            System.out.print('\n');
            shayeste.add(shayestegi);


        }
        int tornumentSize = 2;
        int t_f = shayeste.size() / tornumentSize;

        int[] parent = new int[t_f];
        int count = 0;
        System.out.print('\n');
        while (count < t_f) {
            int u = 0;
            float a = Collections.max(shayeste);

            for (u = 0; u < shayeste.size(); u++) {
                if (shayeste.get(u) == a) {
                    break;
                }

            }
            parent[count] = u + 1;

            System.out.print('\n');

            shayeste.set(u, (float) 0);


            count++;

        }
        findparent(result, parent, number_no_nodes);

    }


    public static void main(String... arg) {
        Scanner scanner = null;

        try {
            System.out.println("Enter the number of nodes in the graph");
            scanner = new Scanner(System.in);
            number_no_nodes = scanner.nextInt();

            int adjacency_matrix[][] = new int[number_no_nodes + 1][number_no_nodes + 1];
            System.out.println("Enter the adjacency matrix");
            for (int i = 1; i <= number_no_nodes; i++)
                for (int j = 1; j <= number_no_nodes; j++)
                    adjacency_matrix[i][j] = scanner.nextInt();
            int[] color = new int[number_no_nodes];
            for (int i = 0; i < color.length; i++) {
                color[i] = -1;
            }
            jenetic v = new jenetic();
            v.jen(adjacency_matrix, color);


        } catch (InputMismatchException inputMismatch) {
            System.out.println("Wrong Input Format");
        }
        scanner.close();
    }

    public static int[][] random(int[] color) {
        popu = 10;
        int[][] population = new int[popu + 1][number_no_nodes + 1];
        int[] code = new int[]{0, 1, 2};
        Random random = new Random();
        int[] set = new int[]{0, 1, 2};
        for (int i = 1; i <= popu; i++) {
            for (int j = 1; j <= number_no_nodes; j++) {
                int rnd = new Random().nextInt(code.length);
                population[i][j] = set[rnd];
                System.out.print(population[i][j]);
            }
            System.out.print(',');
        }
        return population;
    }

    public static float F(int[] state, int edges) {
        float teta = 0;
        for (int t = 1; t < state.length; t++) {
            for (int t2 = 1; t2 < state.length; t2++) {
                if (state[t] != state[t2]) {
                    teta++;
                }
            }
        }
        // System.out.println(teta);
        //  System.out.println(edges);

        float r = teta / edges;
        //  System.out.println(r);
        return r;
    }

    public static void findparent(int[][] result, int[] parent, int length) {
        int counter = 0;
        while (counter < popu / 2) {
            Random random = new Random();
            int rnd11 = 0, rnd22 = 0;


            while (rnd11 == rnd22) {
                int rnd1 = new Random().nextInt(parent.length);
                rnd11 = parent[rnd1];
                int rnd2 = new Random().nextInt(parent.length);
                rnd22 = parent[rnd2];
            }
            int[] p1 = new int[length];
            int p11 = 0;
            int[] p2 = new int[length];
            int p22 = 0;

            for (int r = 1; r <= number_no_nodes; r++) {
                p1[p11] = result[rnd11][r];

                p11++;
            }


            for (int r = 1; r <= number_no_nodes; r++) {
                p2[p22] = result[rnd22][r];


                p22++;
            }
            jenetic mm = new jenetic();
//
            mm.make_kids(p1, p2);
            counter++;
            // System.out.println(counter);

        }
        // jenetic cc=new jenetic();
        // cc.mutatedGenomes(neww,number_no_nodes,popu);
        // System.out.println(counter);

    }

    public void make_kids(int[] p1, int[] p2) {
        int[] kid = new int[p1.length];

        //System.out.print(2*p1.length);
        int k = 0;
        int broken = 2;

        //  kid.add(',');
        for (int l1 = 0; l1 < 2; l1++) {
            kid[k] = p1[l1];
            k++;

        }

        for (int l2 = 2; l2 < p2.length; l2++) {
            kid[k] = p2[l2];
            k++;

        }
        jenetic v = new jenetic();
        v.mutatedGenomes(kid, number_no_nodes, popu);
        //  kid.add(',');
        k = 0;
        for (int l1 = 0; l1 < 2; l1++) {
            kid[k] = p2[l1];
            k++;
        }
        for (int l2 = 2; l2 < p1.length; l2++) {
            kid[k] = p1[l2];
            k++;


        }
        v.mutatedGenomes(kid, number_no_nodes, popu);
        //  System.out.print(kid.length);
        // return kid;
    }

    public void mutatedGenomes(int[] neww, int number_no_nodes, int popu) {
        int[][] new_population = new int[popu + 1][number_no_nodes + 1];
        float mutation = (float) 0.2;
        int g = (int) (number_no_nodes * popu * mutation);

        int[] result = new int[number_no_nodes];
        int[] rand = new int[number_no_nodes];
        int v = 0;
        for (int r = 0; r < number_no_nodes; r++) {
            rand[r] = v;
            v++;
        }
        int r = 0;


        int[] colour = new int[]{0, 1, 2};

        for (int count = 0; count < g; count++) {
            int rnd = new Random().nextInt(rand.length);
            int rang = new Random().nextInt(colour.length);
            neww[rnd] = rang;


        }

        int rr = 0;
        int i_p = 0;
        int j_p = 0;

        i_p = i1;
        for (j_p = 1; j_p <= number_no_nodes; j_p++) {
            new_population[i_p][j_p] = neww[rr];
            System.out.print(new_population[i_p][j_p]);

            rr++;
        }
        System.out.print('\n');
        c++;
        //System.out.println(c);
        int numberOfGenerations=2;



        i1++;


}}
