
package org.arpit.java2blog.graph;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Stack;

class depthlimitedsearch {
    public static int cost=0,memory=0,explore=0;
    int element=0;
    public int DLS(int start, int goal, int depth, int[][] adjacency_matrix, boolean[] visited) {
        Stack<Integer> stack = new Stack<>();
        int number_of_nodes = adjacency_matrix[start].length - 1;
        if (start==goal){return 0;}

        if (start != goal) {
            stack.push(start);
            memory++;
            visited[start] = true;
            explore++;
             element = stack.pop();
            memory--;
            System.out.println(element);

            int i = element;
            while (i <= number_of_nodes) {
                if (adjacency_matrix[element][i] != 0 && visited[i] == false) {
                    stack.push(i);
                    memory++;
                    visited[i] = true;
                    explore++;

                }
                i++;
            }

        }

        while (!stack.empty()) {
            int res = depth;
            int k = res - 1;
            if (k >= 0) {
                int me = stack.pop();
                if (me == goal) {
                    cost=cost+adjacency_matrix[element][me];
                    System.out.println(me);
                   return 0;
                }
                else {
                    cost=cost+adjacency_matrix[element][me];
                DLS(me, goal, k, adjacency_matrix, visited);}

            }
        }
        System.out.println('\n');
        System.out.println("cost"+cost);
        System.out.println("memo"+memory);
        System.out.println("explore"+explore);


        return -1;

    }

    public static void main(String[] args) {
        int number_of_nodes, source;
        Scanner scanner = null;
        try {
            System.out.println("Enter the number of nodes in the graph");
            scanner = new Scanner(System.in);
            number_of_nodes = scanner.nextInt();
            boolean visited[] = new boolean[number_of_nodes + 1];
            int adjacency_matrix[][] = new int[number_of_nodes + 1][number_of_nodes + 1];
            System.out.println("Enter the adjacency matrix");
            for (int i = 1; i <= number_of_nodes; i++)
                for (int j = 1; j <= number_of_nodes; j++)
                    adjacency_matrix[i][j] = scanner.nextInt();

            System.out.println("Enter the source for the graph");
            source = scanner.nextInt();
            System.out.println("Enter the goal");
            int goal = scanner.nextInt();
            System.out.println("Enter the depth");
            int depth = scanner.nextInt();

            System.out.println("The Depth limited Search Traversal");
            depthlimitedsearch dls = new depthlimitedsearch();
            int a = dls.DLS(source, goal, depth, adjacency_matrix, visited);


        } catch (InputMismatchException inputMismatch) {
            System.out.println("Wrong Input format");
        }
        scanner.close();

    }

}
