
package org.arpit.java2blog.graph;

import java.util.Scanner;
import java.util.Stack;

class DepthFirstSearchExample {


    public void dfsUsingStack(int[][] adjacency_matrix, int i, int source, int goal) {
        Stack<Integer> stack = new Stack<>();
        int number_of_nodes = adjacency_matrix[source].length - 1;

        boolean[] visited = new boolean[number_of_nodes + 1];
        int memory = 1, cost = 0, explore = 0, height = 0;
        for (int y = 1; y <= number_of_nodes; y++) {
            visited[y] = false;
        }
        stack.add(source);
        visited[source] = true;
        while (!stack.isEmpty()) {

            int element = stack.pop();
            System.out.println(element);
            if (element == goal) {

                break;
            }
            explore = explore + 1;
            int k = 1;


            while (k <= number_of_nodes) {

                if (adjacency_matrix[element][k] != 0 && visited[k] == false) {

                    stack.add(k);
                    memory = memory + 1;
                    visited[k] = true;
                    cost = adjacency_matrix[element][k] + cost;
                }
                k++;
            }
            height++;


        }
        System.out.println("cost:" + cost);

        System.out.println("explore:" + explore);
        System.out.println("memory:" + memory);
        System.out.println("height:" + height);
    }

    public static void main(String arg[]) {
        Scanner scanner = null;

        System.out.println("Enter the number of nodes in the graph");
        scanner = new Scanner(System.in);
        int number_no_nodes = scanner.nextInt();

        int adjacency_matrix[][] = new int[number_no_nodes + 1][number_no_nodes + 1];
        System.out.println("Enter the adjacency matrix");
        for (int i = 1; i <= number_no_nodes; i++)
            for (int j = 1; j <= number_no_nodes; j++)
                adjacency_matrix[i][j] = scanner.nextInt();
        System.out.println("enter your goal node");
        int goal = scanner.nextInt();
        System.out.println("Enter the source for the graph");
        int source = scanner.nextInt();


        DepthFirstSearchExample dfsExample = new DepthFirstSearchExample();

        System.out.println("The DFS traversal");
        dfsExample.dfsUsingStack(adjacency_matrix, source, source, goal);


    }

}