

import java.util.*;


class Graph {
    public static int initial = 0;
    public int min = 1000;
    public static int counter = 0;
    public static int explored=0,seen=0;

    public void hill(int[][] adjacency_matrix, int number_node, int[] color) {
        int[] total = new int[color.length];
        int k = 0;
        Graph b = new Graph();
        int res = 0;
        while (k < number_node) {
            if (color[k] == -1) {
                color[k] = 0;
                res = b.F(color, adjacency_matrix);
                if (res <= min) {
                    min = res;
                    for (int y = 0; y < color.length; y++) {
                        total[y] = color[y];
                    }

                }

                color[k] = 1;
                res = b.F(color, adjacency_matrix);
                if (res <= min) {
                    min = res;
                    for (int y = 0; y < color.length; y++) {
                        total[y] = color[y];
                    }

                }
                color[k] = 2;
                res = b.F(color, adjacency_matrix);
                if (res <= min) {
                    min = res;
                    for (int y = 0; y < color.length; y++) {
                        total[y] = color[y];
                    }

//                }
                    color[k] = -1;


                }


            }


            k++;
        }
        counter++;


        if (counter <= color.length-2) {
            hill(adjacency_matrix, number_node, total);

        }
        else{   for(int v=0;v<total.length;v++){
            System.out.println(total[v]);
        }}


    }

    public int F(int[] color, int[][] adjacency_matrix) {
        int f = 0;
        for (int i = 0; i < color.length; i++) {
            for (int j = 0; j < color.length; j++) {
                if (adjacency_matrix[i][j] == 1) {
                    int v = color[i];
                    int h = color[j];
                    if (v == h) {
                        if (v != -1) {
                            f++;
                        }
                    }
                }
            }
        }
        return f;

    }

    public static void main(String args[]) {
        Scanner scanner = null;
        int number_nodes = 0;
       // try {
        System.out.println("Enter the number of nodes in the graph");
        scanner = new Scanner(System.in);
        number_nodes = scanner.nextInt();
        int adjacency_matrix[][] = new int[number_nodes][number_nodes];
        System.out.println("Enter the adjacency matrix");
        for (int i = 0; i <number_nodes; i++)
            for (int j = 0; j < number_nodes; j++)
                adjacency_matrix[i][j] = scanner.nextInt();


        //} catch (InputMismatchException inputMismatch) {
         //   System.out.println("Wrong Input format");
       // }

        int[] color = new int[number_nodes];
        for (int i = 0; i < color.length; i++) {
            color[i] = -1;
        }
        color[initial] = 0;
        Graph tt = new Graph();
        tt.hill(adjacency_matrix, number_nodes, color);

    }


}



